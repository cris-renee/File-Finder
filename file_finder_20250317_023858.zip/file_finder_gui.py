import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from datetime import datetime
import os
import subprocess
import platform
from search_engine import FileSearchEngine

class FileFinder(tk.Tk):
    def __init__(self):
        super().__init__()

        # Window setup
        self.title("File Finder")
        self.geometry("900x600")
        self.configure(padx=10, pady=10)

        # Search engine initialization
        self.search_engine = FileSearchEngine()

        # Create main frame
        self.main_frame = ttk.Frame(self)
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        # Create and place widgets
        self.create_search_frame()
        self.create_results_frame()
        self.create_status_bar()
        self.create_context_menu()

        # Add tooltips
        self.create_tooltips()

    def create_search_frame(self):
        # Search criteria frame
        search_frame = ttk.LabelFrame(self.main_frame, text="Search Settings", padding="10")
        search_frame.pack(fill=tk.X, padx=5, pady=5)

        # File pattern
        ttk.Label(search_frame, text="Search pattern:").grid(row=0, column=0, sticky=tk.W, padx=5)
        self.pattern_var = tk.StringVar(value="*.*")
        pattern_frame = ttk.Frame(search_frame)
        pattern_frame.grid(row=0, column=1, sticky=tk.EW, padx=5)
        self.pattern_entry = ttk.Entry(pattern_frame, textvariable=self.pattern_var)
        self.pattern_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(pattern_frame, text="Clear", command=lambda: self.pattern_var.set("*.*")).pack(side=tk.RIGHT)

        # Path selection
        ttk.Label(search_frame, text="Search in:").grid(row=1, column=0, sticky=tk.W, padx=5)
        self.path_var = tk.StringVar(value=os.getcwd())
        path_frame = ttk.Frame(search_frame)
        path_frame.grid(row=1, column=1, sticky=tk.EW, padx=5)
        self.path_entry = ttk.Entry(path_frame, textvariable=self.path_var)
        self.path_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(path_frame, text="Browse", command=self.browse_path).pack(side=tk.RIGHT)

        # Search type
        ttk.Label(search_frame, text="Search for:").grid(row=2, column=0, sticky=tk.W, padx=5)
        self.type_var = tk.StringVar(value="both")
        type_frame = ttk.Frame(search_frame)
        type_frame.grid(row=2, column=1, sticky=tk.EW, padx=5)
        for value, text in [("files", "Files"), ("folders", "Folders"), ("both", "Both")]:
            ttk.Radiobutton(type_frame, text=text, value=value, 
                          variable=self.type_var).pack(side=tk.LEFT, padx=5)

        # Sort options
        ttk.Label(search_frame, text="Sort by:").grid(row=3, column=0, sticky=tk.W, padx=5)
        self.sort_var = tk.StringVar(value="name")
        sort_frame = ttk.Frame(search_frame)
        sort_frame.grid(row=3, column=1, sticky=tk.EW, padx=5)
        for value, text in [("name", "Name"), ("date", "Date"), ("size", "Size"), ("type", "Type")]:
            ttk.Radiobutton(sort_frame, text=text, value=value, 
                          variable=self.sort_var).pack(side=tk.LEFT, padx=5)

        # Search button
        ttk.Button(search_frame, text="Search", 
                  command=self.perform_search).grid(row=4, column=0, columnspan=2, pady=10)

        # Configure grid
        search_frame.columnconfigure(1, weight=1)

    def create_results_frame(self):
        # Results frame
        results_frame = ttk.LabelFrame(self.main_frame, text="Search Results", padding="10")
        results_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Create treeview with scrollbars
        self.tree = ttk.Treeview(results_frame, 
                                columns=("type", "name", "path", "size", "modified"),
                                show="headings", selectmode="browse")

        # Scrollbars
        vsb = ttk.Scrollbar(results_frame, orient=tk.VERTICAL, command=self.tree.yview)
        hsb = ttk.Scrollbar(results_frame, orient=tk.HORIZONTAL, command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        # Grid layout
        self.tree.grid(row=0, column=0, sticky=tk.NSEW)
        vsb.grid(row=0, column=1, sticky=tk.NS)
        hsb.grid(row=1, column=0, sticky=tk.EW)

        # Configure columns
        self.tree.heading("type", text="Type", command=lambda: self.sort_column("type"))
        self.tree.heading("name", text="Name", command=lambda: self.sort_column("name"))
        self.tree.heading("path", text="Path", command=lambda: self.sort_column("path"))
        self.tree.heading("size", text="Size", command=lambda: self.sort_column("size"))
        self.tree.heading("modified", text="Modified", command=lambda: self.sort_column("modified"))

        # Column widths
        self.tree.column("type", width=60, minwidth=60)
        self.tree.column("name", width=150, minwidth=100)
        self.tree.column("path", width=300, minwidth=200)
        self.tree.column("size", width=100, minwidth=80)
        self.tree.column("modified", width=150, minwidth=100)

        # Configure grid weights
        results_frame.columnconfigure(0, weight=1)
        results_frame.rowconfigure(0, weight=1)

        # Bind double-click and right-click events
        self.tree.bind('<Double-1>', self.open_item)
        self.tree.bind('<Button-3>', self.show_context_menu)

    def create_context_menu(self):
        """Create right-click context menu"""
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="Open", command=self.open_selected)
        self.context_menu.add_command(label="Open Containing Folder", 
                                    command=self.open_containing_folder)

    def show_context_menu(self, event):
        """Show context menu on right click"""
        if self.tree.selection():
            self.context_menu.tk_popup(event.x_root, event.y_root)

    def open_item(self, event=None):
        """Handle double-click on item"""
        if self.tree.selection():
            self.open_selected()

    def open_selected(self):
        """Open the selected file or folder"""
        if not self.tree.selection():
            return

        item = self.tree.selection()[0]
        path = self.tree.item(item)['values'][2]  # Path is in the third column

        if os.path.exists(path):
            if platform.system() == 'Windows':
                os.startfile(path)
            elif platform.system() == 'Darwin':  # macOS
                subprocess.run(['open', path])
            else:  # Linux
                subprocess.run(['xdg-open', path])

    def open_containing_folder(self):
        """Open the folder containing the selected item"""
        if not self.tree.selection():
            return

        item = self.tree.selection()[0]
        path = self.tree.item(item)['values'][2]  # Path is in the third column

        # Get the parent directory
        parent_dir = os.path.dirname(path)

        if os.path.exists(parent_dir):
            if platform.system() == 'Windows':
                os.startfile(parent_dir)
            elif platform.system() == 'Darwin':  # macOS
                subprocess.run(['open', parent_dir])
            else:  # Linux
                subprocess.run(['xdg-open', parent_dir])

    def create_status_bar(self):
        self.status_var = tk.StringVar()
        status_bar = ttk.Label(self.main_frame, textvariable=self.status_var, relief=tk.SUNKEN)
        status_bar.pack(fill=tk.X, padx=5, pady=5)
        self.status_var.set("Ready")

    def create_tooltips(self):
        self.pattern_entry.bind('<Enter>', lambda e: self.show_tooltip(
            "Enter search pattern (e.g., *.txt, *.pdf, doc*.docx)"))
        self.pattern_entry.bind('<Leave>', lambda e: self.hide_tooltip())

    def show_tooltip(self, text):
        x, y, _, _ = self.pattern_entry.bbox("insert")
        x += self.pattern_entry.winfo_rootx() + 25
        y += self.pattern_entry.winfo_rooty() + 20

        self.tooltip = tk.Toplevel(self)
        self.tooltip.wm_overrideredirect(True)
        self.tooltip.wm_geometry(f"+{x}+{y}")

        label = ttk.Label(self.tooltip, text=text, justify=tk.LEFT,
                         background="#ffffe0", relief=tk.SOLID, borderwidth=1,
                         padding=(5,5))
        label.pack()

    def hide_tooltip(self):
        if hasattr(self, "tooltip"):
            self.tooltip.destroy()

    def browse_path(self):
        path = filedialog.askdirectory(initialdir=self.path_var.get())
        if path:
            self.path_var.set(path)

    def format_size(self, size):
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} PB"

    def perform_search(self):
        # Clear previous results
        for item in self.tree.get_children():
            self.tree.delete(item)

        self.status_var.set("Searching...")
        self.update_idletasks()

        try:
            # Perform search
            results = self.search_engine.search(
                path=self.path_var.get(),
                name_pattern=self.pattern_var.get(),
                sort_by=self.sort_var.get(),
                include_type=self.type_var.get()
            )

            # Display results
            for result in results:
                self.tree.insert("", tk.END, values=(
                    result['type'],
                    result['name'],
                    result['path'],
                    self.format_size(result['size']),
                    result['modified'].strftime('%Y-%m-%d %H:%M:%S')
                ))

            self.status_var.set(f"Found {len(results)} items")

        except Exception as e:
            messagebox.showerror("Error", str(e))
            self.status_var.set("Search failed")

    def sort_column(self, col):
        items = [(self.tree.set(item, col), item) for item in self.tree.get_children('')]
        items.sort()
        for index, (_, item) in enumerate(items):
            self.tree.move(item, '', index)

if __name__ == "__main__":
    app = FileFinder()
    app.mainloop()