import os
import fnmatch
from datetime import datetime
from typing import List, Dict, Optional

class FileSearchEngine:
    def __init__(self):
        self.results = []

    def _get_folder_size(self, folder_path: str) -> int:
        """Calculate total size of a folder"""
        total_size = 0
        try:
            for dirpath, dirnames, filenames in os.walk(folder_path):
                for filename in filenames:
                    file_path = os.path.join(dirpath, filename)
                    try:
                        total_size += os.path.getsize(file_path)
                    except (PermissionError, FileNotFoundError):
                        continue
        except (PermissionError, FileNotFoundError):
            pass
        return total_size

    def search(self, 
               path: str, 
               name_pattern: Optional[str] = None,
               date: Optional[datetime] = None,
               before_date: Optional[datetime] = None,
               after_date: Optional[datetime] = None,
               sort_by: str = 'name',
               include_type: str = 'both') -> List[Dict]:
        """Search for files and/or folders matching the given criteria"""
        self.results = []

        # Validate the search path exists
        path = os.path.abspath(os.path.expanduser(path))
        if not os.path.exists(path):
            raise ValueError(f"Path does not exist: {path}")

        # Walk through directory tree
        for root, dirs, files in os.walk(path):
            # Check folders if requested
            if include_type in ['folders', 'both']:
                for dir_name in dirs:
                    dir_path = os.path.join(root, dir_name)
                    try:
                        stat = os.stat(dir_path)
                        if self._matches_criteria(
                            path=dir_path,
                            file_stat=stat,
                            name_pattern=name_pattern,
                            date=date,
                            before_date=before_date,
                            after_date=after_date
                        ):
                            self.results.append({
                                'name': dir_name,
                                'path': dir_path,
                                'size': self._get_folder_size(dir_path),
                                'modified': datetime.fromtimestamp(stat.st_mtime),
                                'created': datetime.fromtimestamp(stat.st_ctime),
                                'type': 'folder'
                            })
                    except (PermissionError, FileNotFoundError):
                        continue

            # Check files if requested
            if include_type in ['files', 'both']:
                for file_name in files:
                    file_path = os.path.join(root, file_name)
                    try:
                        stat = os.stat(file_path)
                        if self._matches_criteria(
                            path=file_path,
                            file_stat=stat,
                            name_pattern=name_pattern,
                            date=date,
                            before_date=before_date,
                            after_date=after_date
                        ):
                            self.results.append({
                                'name': file_name,
                                'path': file_path,
                                'size': stat.st_size,
                                'modified': datetime.fromtimestamp(stat.st_mtime),
                                'created': datetime.fromtimestamp(stat.st_ctime),
                                'type': 'file'
                            })
                    except (PermissionError, FileNotFoundError):
                        continue

        # Sort results based on criteria
        self._sort_results(sort_by)
        return self.results

    def _matches_criteria(self, 
                         path: str,
                         file_stat: os.stat_result,
                         name_pattern: Optional[str],
                         date: Optional[datetime],
                         before_date: Optional[datetime],
                         after_date: Optional[datetime]) -> bool:
        """Check if an item matches all search criteria"""

        # Check name pattern
        if name_pattern and not fnmatch.fnmatch(os.path.basename(path), name_pattern):
            return False

        # Check exact date
        if date:
            file_date = datetime.fromtimestamp(file_stat.st_mtime).date()
            if file_date != date.date():
                return False

        # Check before date
        if before_date:
            file_date = datetime.fromtimestamp(file_stat.st_mtime)
            if file_date >= before_date:
                return False

        # Check after date
        if after_date:
            file_date = datetime.fromtimestamp(file_stat.st_mtime)
            if file_date <= after_date:
                return False

        return True

    def _sort_results(self, sort_by: str):
        """Sort results based on specified criteria"""
        if sort_by == 'name':
            self.results.sort(key=lambda x: x['name'].lower())
        elif sort_by == 'date':
            self.results.sort(key=lambda x: x['modified'], reverse=True)
        elif sort_by == 'size':
            self.results.sort(key=lambda x: x['size'], reverse=True)
        elif sort_by == 'type':
            self.results.sort(key=lambda x: (x['type'], x['name'].lower()))