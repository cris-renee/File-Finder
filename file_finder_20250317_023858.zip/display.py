from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from datetime import datetime
import os

class DisplayManager:
    """
    Handles the display formatting of search results using Rich library.
    This makes our output look nice in the terminal.
    """
    def __init__(self):
        # Initialize Rich console
        self.console = Console()

    def show_results(self, results):
        """Display search results in a formatted table"""
        if not results:
            # Show message if no files found
            self.console.print(Panel("No files found matching the search criteria",
                                   style="yellow"))
            return

        # Create table with headers
        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("File Name")
        table.add_column("Path")
        table.add_column("Size", justify="right")
        table.add_column("Modified")

        # Add each result as a row
        for result in results:
            size = self._format_size(result['size'])
            modified = result['modified'].strftime('%Y-%m-%d %H:%M:%S')

            table.add_row(
                result['name'],
                result['path'],
                size,
                modified
            )

        # Show summary and table
        self.console.print(Panel(f"Found {len(results)} files", style="green"))
        self.console.print(table)

    def show_error(self, message):
        """Display error message"""
        self.console.print(Panel(f"Error: {message}", style="bold red"))

    def _format_size(self, size_bytes):
        """Format file size in human-readable format"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size_bytes < 1024:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024
        return f"{size_bytes:.1f} PB"