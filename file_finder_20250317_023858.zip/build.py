import PyInstaller.__main__
import os

# Get the current directory
current_dir = os.path.dirname(os.path.abspath(__file__))

PyInstaller.__main__.run([
    'file_finder_gui.py',
    '--onefile',  # Create a single executable file
    '--windowed',  # Hide the console window when running
    '--name=FileFinder',
    '--add-data=search_engine.py:.',
    '--add-data=display.py:.',
    '--icon=NONE',
    '--clean'  # Clean PyInstaller cache
])