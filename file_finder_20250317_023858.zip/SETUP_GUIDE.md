# Complete Setup Guide for File Finder Application

## Step 1: Create Project Directory
1. Create a new folder named `file_finder` on your computer
2. Download and copy these files into the folder:

### Required Files:

1. `file_finder_gui.py` - Main GUI application
2. `search_engine.py` - Search functionality
3. `display.py` - Display formatting
4. `build.py` - Creates executable
5. `pyproject.toml` - Project configuration

## Step 2: Install Requirements
Open Command Prompt (Windows) or Terminal (Mac/Linux) and run:
```bash
pip install rich pyinstaller
```

## Step 3: Build the Executable
1. Navigate to your project folder:
```bash
cd path/to/file_finder
```

2. Run the build script:
```bash
python build.py
```

3. Find your executable in the `dist` folder:
   - Windows: `FileFinder.exe`
   - Mac/Linux: `FileFinder`

## Step 4: Run the Application
Simply double-click the executable in the `dist` folder to launch File Finder!

## Using File Finder

1. Type a search pattern (e.g., *.txt, *.pdf)
2. Click "Browse" to select a folder to search in
3. Choose how to sort results (by name, date, or size)
4. Click "Search" to find your files
5. Results will show in the table below

## Tips
- Use * for any characters: *.txt finds all text files
- Use ? for single character: file?.txt finds file1.txt, fileA.txt, etc.
- Click column headers to sort results
